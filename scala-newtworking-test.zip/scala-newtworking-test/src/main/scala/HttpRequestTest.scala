import scalaj.http.Http

object HttpRequestTest extends App {
//  println(Http("https://ru.wikipedia.org/wiki/HTTP").param("format","json").asString.body )
//  println(Http("https://swapi.co/api/planets/3/").param("format","json").asString.body )
//  println(Http("https://swapi.co/api/planets/3/").param("format","json").asString.headers )
//  println(Http("https://swapi.co/api/planets/3/").param("format","json").asString.code )
}
